package com.zaki.myexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyExamApplicationTests {

    @Test
    void contextLoads() {
    }
}
