package com.project.TripHub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripHubApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripHubApplication.class, args);
	}

}
