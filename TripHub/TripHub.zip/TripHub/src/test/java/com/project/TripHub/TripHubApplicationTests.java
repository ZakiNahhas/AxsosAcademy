package com.project.TripHub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
